import React from 'react'
import { View, Text } from 'react-native'

const CartScreen = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Cart Screen</Text>
    </View>
  )
}

export default CartScreen
