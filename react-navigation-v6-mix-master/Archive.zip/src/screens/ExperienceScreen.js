import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import UserAvatar from 'react-native-user-avatar';

const ExperienceList = () => {
  return (
    <View>
      <Text>ExperienceList</Text>
    </View>
  );
};

export default ExperienceList;

export const ExperienceDetail = () => {
  return (
    <View>
      <Text>ExperienceDetail</Text>
    </View>
  );
};
