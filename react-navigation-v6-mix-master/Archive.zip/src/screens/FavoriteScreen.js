import React from 'react'
import { View, Text } from 'react-native'

const FavoriteScreen = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Favorite Screen</Text>
    </View>
  )
}

export default FavoriteScreen